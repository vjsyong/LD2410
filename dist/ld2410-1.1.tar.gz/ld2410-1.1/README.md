# LD2410

Documentation coming soon. In the meantime, you can read example.py to figure out how to use the module